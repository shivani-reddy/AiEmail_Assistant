package com.email.AIEmail_writer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiEmailWriterApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiEmailWriterApplication.class, args);
	}

}
